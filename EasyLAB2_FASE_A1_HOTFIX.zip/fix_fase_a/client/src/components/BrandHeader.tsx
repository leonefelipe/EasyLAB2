/**
 * BrandHeader.tsx
 * Cabeçalho com identidade visual Leone Berto Consultoria.
 * Usa as cores extraídas do logo oficial:
 *   Navy  #0C2539 | Gold #A08246 | Beige #F4EEE9
 *
 * Uso:
 *   <BrandHeader />                         → versão padrão (dark navy)
 *   <BrandHeader variant="light" />         → fundo bege, texto navy
 *   <BrandHeader compact />                 → versão menor para mobile
 *   <BrandHeader showTagline={false} />     → sem subtítulo
 */

import React from "react";

interface BrandHeaderProps {
  variant?: "dark" | "light";
  compact?: boolean;
  showTagline?: boolean;
  className?: string;
}

// ── Logo SVG inline — fiel à identidade visual ───────────────────────────────
function LBLogoSVG({ variant = "dark", size = 44 }: { variant?: "dark" | "light"; size?: number }) {
  const navy  = variant === "dark" ? "#F4EEE9" : "#0C2539"; // texto invertido no dark bg
  const gold  = "#A08246";

  return (
    <svg
      width={size * 2.8}
      height={size}
      viewBox="0 0 140 50"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Leone Berto Consultoria"
    >
      {/* ── Monograma LB ─────────────────────────────────────── */}
      {/* Letra L */}
      <text
        x="2" y="38"
        fontFamily="'Playfair Display', Georgia, serif"
        fontSize="40"
        fontWeight="700"
        fontStyle="italic"
        fill={navy}
      >L</text>

      {/* Letra B (dourado) */}
      <text
        x="22" y="38"
        fontFamily="'Playfair Display', Georgia, serif"
        fontSize="34"
        fontWeight="700"
        fontStyle="italic"
        fill={gold}
      >B</text>

      {/* Seta diagonal (dourado) */}
      <line x1="28" y1="36" x2="38" y2="26" stroke={gold} strokeWidth="1.8" strokeLinecap="round"/>
      <polygon points="38,26 33,28 36,33" fill={gold}/>

      {/* ── Separador vertical ───────────────────────────────── */}
      <line x1="56" y1="6" x2="56" y2="44" stroke={navy} strokeWidth="1" opacity="0.5"/>

      {/* ── LEONE BERTO ──────────────────────────────────────── */}
      <text
        x="64" y="28"
        fontFamily="'Playfair Display', Georgia, serif"
        fontSize="18"
        fontWeight="700"
        fill={navy}
        letterSpacing="1.5"
      >LEONE BERTO</text>

      {/* ── Linha + CONSULTORIA + Linha ──────────────────────── */}
      <line x1="64" y1="33" x2="88" y2="33" stroke={gold} strokeWidth="0.8"/>
      <text
        x="91" y="37"
        fontFamily="'Inter', Arial, sans-serif"
        fontSize="6"
        fontWeight="500"
        fill={gold}
        letterSpacing="2.5"
      >CONSULTORIA</text>
      <line x1="158" y1="33" x2="195" y2="33" stroke={gold} strokeWidth="0.8"/>
    </svg>
  );
}

// ── Componente principal ──────────────────────────────────────────────────────
export function BrandHeader({
  variant = "dark",
  compact = false,
  showTagline = true,
  className = "",
}: BrandHeaderProps) {
  const isDark = variant === "dark";

  const containerStyle: React.CSSProperties = {
    background:   isDark ? "#0C2539" : "#F4EEE9",
    borderBottom: `2px solid #A08246`,
    padding:      compact ? "0.6rem 1.25rem" : "0.85rem 1.75rem",
    display:      "flex",
    alignItems:   "center",
    justifyContent: "space-between",
    gap:          "1rem",
  };

  const taglineStyle: React.CSSProperties = {
    fontFamily:    "'Inter', Arial, sans-serif",
    fontSize:      compact ? "0.55rem" : "0.62rem",
    letterSpacing: "0.22em",
    textTransform: "uppercase" as const,
    color:         isDark ? "rgba(244,238,233,0.55)" : "rgba(12,37,57,0.5)",
    marginTop:     "0.25rem",
    whiteSpace:    "nowrap" as const,
  };

  return (
    <header style={containerStyle} className={className}>
      {/* Logo */}
      <div style={{ display: "flex", flexDirection: "column" }}>
        <LBLogoSVG variant={isDark ? "dark" : "light"} size={compact ? 34 : 44} />
        {showTagline && !compact && (
          <p style={taglineStyle}>Estratégia de Carreira e Posicionamento Profissional</p>
        )}
      </div>

      {/* Slot direito — pode receber children (ex: botão de perfil, modo escuro) */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
        {/* Aqui entra ThemeToggle, UserMenu, etc. */}
      </div>
    </header>
  );
}

export default BrandHeader;
