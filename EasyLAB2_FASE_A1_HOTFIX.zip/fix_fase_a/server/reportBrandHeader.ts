/**
 * reportBrandHeader.ts
 * Tokens, funções e snippets de branding Leone Berto Consultoria.
 * Usado por: clientReportGenerator.ts, pdfGenerator.ts, e qualquer
 * componente que precise das cores ou do logo inline.
 *
 * NÃO depende de jsPDF — o relatório usa HTML + browser print.
 *
 * Cores extraídas pixel a pixel do logo oficial Leone Berto
 * (leone_berto_material_apresentacao.pdf — abril/2026).
 */

// ── Paleta oficial Leone Berto ─────────────────────────────────────────────────
export const LB_COLORS = {
  navy:      "#0C2539",   // Azul marinho primário (fundo dark, sidebar, botões)
  navy2:     "#132B45",   // Azul escuro (texto, headings)
  gold:      "#A08246",   // Dourado (CONSULTORIA, linha decorativa, acentos)
  goldLight: "#C4A35A",   // Dourado claro (hovers, highlights)
  beige:     "#F4EEE9",   // Bege (fundo versão clara, cards)
  beigeDeep: "#EDE8E2",   // Bege escuro (muted background)
  gray:      "#6B5F54",   // Cinza quente (muted text, subtítulos)
  grayLight: "#DDD6CF",   // Cinza claro (borders, dividers)
  white:     "#FFFFFF",
} as const;

export type LBColor = keyof typeof LB_COLORS;

// ── Fontes da marca ────────────────────────────────────────────────────────────
export const LB_FONTS = {
  serif: "'Playfair Display', Georgia, 'Times New Roman', serif",
  sans:  "'Inter', Arial, 'Helvetica Neue', sans-serif",
} as const;

export const LB_GOOGLE_FONTS_URL =
  "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Inter:wght@400;500;600;700&display=swap";

// ── Logo SVG inline ────────────────────────────────────────────────────────────
export function lbLogoSVG(variant: "dark" | "light" = "light", width = 320): string {
  const textColor = variant === "dark" ? LB_COLORS.beige : LB_COLORS.navy;
  const gold      = LB_COLORS.gold;
  const h         = Math.round(width * 0.22);

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 380 68"
    width="${width}" height="${h}" role="img" aria-label="Leone Berto Consultoria" style="display:block">
    <text x="4" y="52" font-family="Georgia,'Times New Roman',serif"
      font-size="52" font-weight="700" font-style="italic" fill="${textColor}">L</text>
    <text x="30" y="52" font-family="Georgia,'Times New Roman',serif"
      font-size="44" font-weight="700" font-style="italic" fill="${gold}">B</text>
    <line x1="36" y1="48" x2="50" y2="34" stroke="${gold}" stroke-width="1.8" stroke-linecap="round"/>
    <polygon points="50,34 44,37 47,43" fill="${gold}"/>
    <line x1="72" y1="8" x2="72" y2="60" stroke="${textColor}" stroke-width="1" opacity="0.5"/>
    <text x="82" y="38" font-family="Georgia,'Times New Roman',serif"
      font-size="22" font-weight="700" letter-spacing="2" fill="${textColor}">LEONE BERTO</text>
    <line x1="82" y1="45" x2="118" y2="45" stroke="${gold}" stroke-width="0.8"/>
    <text x="121" y="49" font-family="Arial,Helvetica,sans-serif"
      font-size="7.5" font-weight="500" letter-spacing="3" fill="${gold}">CONSULTORIA</text>
    <line x1="228" y1="45" x2="378" y2="45" stroke="${gold}" stroke-width="0.8"/>
    <text x="82" y="63" font-family="Arial,Helvetica,sans-serif"
      font-size="6" letter-spacing="1.8" fill="${textColor}" opacity="0.6">ESTRATÉGIA DE CARREIRA E POSICIONAMENTO PROFISSIONAL</text>
  </svg>`;
}

// ── Linha decorativa dourada ───────────────────────────────────────────────────
export function lbGoldDivider(label?: string): string {
  if (label) {
    return `<div style="display:flex;align-items:center;gap:10px;margin:8px 0;opacity:0.7">
      <div style="flex:1;height:1px;background:${LB_COLORS.gold}"></div>
      <span style="font-family:${LB_FONTS.sans};font-size:7pt;letter-spacing:2px;text-transform:uppercase;color:${LB_COLORS.gold};white-space:nowrap">${label}</span>
      <div style="flex:1;height:1px;background:${LB_COLORS.gold}"></div>
    </div>`;
  }
  return `<div style="height:1px;background:linear-gradient(to right,${LB_COLORS.gold},rgba(160,130,70,0.1));margin:8px 0"></div>`;
}

// ── Badge de score ─────────────────────────────────────────────────────────────
export function lbScoreBadge(score: number, size = 64): string {
  const color    = score >= 75 ? "#16a34a" : score >= 55 ? LB_COLORS.gold : "#dc2626";
  const fontSize = Math.round(size * 0.35);
  return `<div style="
    width:${size}px;height:${size}px;border-radius:50%;
    background:${LB_COLORS.navy};border:2px solid ${LB_COLORS.gold};
    display:inline-flex;align-items:center;justify-content:center;
    font-family:${LB_FONTS.serif};font-size:${fontSize}pt;font-weight:700;
    color:${color};flex-shrink:0">${score}</div>`;
}

// ── Card com borda dourada ─────────────────────────────────────────────────────
export function lbCard(content: string, accentColor = LB_COLORS.gold): string {
  return `<div style="
    background:${LB_COLORS.beige};
    border:1px solid ${LB_COLORS.grayLight};
    border-left:3px solid ${accentColor};
    border-radius:0 6px 6px 0;
    padding:14px 16px;
    margin-bottom:10px">${content}</div>`;
}

// ── Título de seção ────────────────────────────────────────────────────────────
export function lbSectionTitle(title: string): string {
  return `<div style="
    font-family:${LB_FONTS.sans};
    font-size:7pt;font-weight:700;
    text-transform:uppercase;letter-spacing:2px;
    color:${LB_COLORS.navy};
    background:${LB_COLORS.beige};
    border-left:3px solid ${LB_COLORS.gold};
    padding:5px 10px;
    margin-bottom:12px">${title}</div>`;
}

// ── CSS de tema completo (para injetar em style tags) ──────────────────────────
export function lbThemeCSS(): string {
  return `
    :root {
      --lb-navy:       ${LB_COLORS.navy};
      --lb-navy2:      ${LB_COLORS.navy2};
      --lb-gold:       ${LB_COLORS.gold};
      --lb-gold-light: ${LB_COLORS.goldLight};
      --lb-beige:      ${LB_COLORS.beige};
      --lb-gray:       ${LB_COLORS.gray};
      --lb-gray-light: ${LB_COLORS.grayLight};
    }
    .lb-section-title {
      font-size:7pt;font-weight:700;
      text-transform:uppercase;letter-spacing:2px;
      color:var(--lb-navy);
      background:var(--lb-beige);
      border-left:3px solid var(--lb-gold);
      padding:5px 10px;margin-bottom:12px;
    }
    .lb-card {
      background:var(--lb-beige);
      border:1px solid var(--lb-gray-light);
      border-left:3px solid var(--lb-gold);
      border-radius:0 6px 6px 0;
      padding:14px 16px;
    }
    .lb-gold-divider {
      display:flex;align-items:center;gap:10px;
      margin:8px 0;opacity:0.7;
    }
    .lb-gold-divider::before,
    .lb-gold-divider::after {
      content:'';flex:1;height:1px;background:var(--lb-gold);
    }
  `;
}
