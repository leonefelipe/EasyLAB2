# FASE A.1 — HOTFIX (Upload PDF/DOCX + Branding Leone Berto)

## ⏱️ Instalação — 3 minutos

Cada arquivo abaixo substitui um arquivo **que já existe** no seu projeto. Mesmo caminho, mesma estrutura. Você pode arrastar tudo por cima da pasta `EasyLAB2-main` que funciona.

| Arquivo do ZIP | Substitui em |
|---|---|
| `client/src/lib/fileExtractor.ts` | idem (fix do worker PDF) |
| `client/src/pages/ClientDashboard.tsx` | idem (fix DOCX no Android) |
| `client/src/components/AnalysisLayout.tsx` | idem (fix DOCX no Android) |
| `client/src/components/BrandHeader.tsx` | **novo arquivo** (criar) |
| `client/src/index.css` | idem (tema Leone Berto) |
| `client/public/leone_berto_logo.svg` | **novo arquivo** (criar) |
| `server/resumeRouter.ts` | idem (fix scraping Inhire + anti-403) |
| `server/reportBrandHeader.ts` | **novo arquivo** (criar) |

Depois:
```bash
pnpm install      # garantir pdfjs-dist está ok
pnpm dev          # testar LOCAL antes de deploy
```

---

## ✅ O que cada fix resolve

### 1. Upload PDF — "Setting up fake worker failed"
**Causa:** `pdfjs-dist@5.6.205` tem worker como `.mjs`, mas o código pedia `.js` no cdnjs (404).
**Fix:** worker agora é bundled pelo Vite (import `?url`). Sem CDN, sem 404.

### 2. Upload DOCX abre câmera no Android
**Causa:** `accept=".pdf,.docx,.txt"` sem MIME types. Android Chrome cai no picker de mídia.
**Fix:** adicionei os 3 MIME types. Agora abre o seletor de arquivos direto.

### 3. Scraping de vaga — Inhire retornando 403
**Causa:** servidor do Inhire bloqueava requisição sem headers de browser real.
**Fix:** headers de browser + detecção de challenge (Cloudflare) + tentativa via API pública do Inhire (`api.inhire.com.br`). Se API falhar, cai no HTML com headers beefados.

### 4. Branding Leone Berto
Aplicado no tema CSS (navy `#0C2539` + dourado `#A08246`) e componentes (`BrandHeader`, helpers do relatório PDF).

---

## 🧪 Como testar ANTES de deployar (5 minutos)

Não teste em produção. Teste local. É 10× mais rápido.

```bash
cd EasyLAB2
pnpm dev
# abre em http://localhost:3000 no seu PC
```

**Checklist rápido (passe por todos antes de `git push`):**

1. [ ] **PDF:** Upload → extrai texto sem erro de "fake worker"
2. [ ] **DOCX:** Upload → extrai texto (teste no desktop + mobile)
3. [ ] **Vaga Inhire:** Colar `https://eveo.inhire.app/vagas/aeb924ef-dc7e-4539-8a59-17089c9ece9a/executivo-de-vendas-consultivas` → scraping funciona OU a análise cai em modo "URL detectada, descrição não extraída"
4. [ ] **Vaga em branco:** "Analisar CV (geral)" — funciona
5. [ ] **Branding:** ver cores navy + dourado no header/cards
6. [ ] **Mobile real:** abrir em `http://<seu-ip-local>:3000` no celular

Para testar no celular durante o dev: descobre seu IP local com `ipconfig` (Win) ou `ifconfig` (Mac/Linux), e abre `http://192.168.x.x:3000` no celular (mesma wifi).

---

## ⚠️ Item pendente — LinkedIn "puxando do CV"

Ainda preciso de **1 print** seu para diagnosticar:
- Em qual tela isso acontece? Rota `/` (dashboard) ou `/linkedin` (página dedicada)?
- O texto aparece onde — no campo "Perfil do LinkedIn" ou no resultado da análise?

**Se for no resultado da análise (tab "LinkedIn" dentro do resultado):** isso é **comportamento esperado**. A análise do CV gera automaticamente uma otimização de LinkedIn baseada no conteúdo do currículo (headline, about, skills). Não é scraping do LinkedIn — é inferência do GPT-4o a partir do CV.

Se você quer desacoplar e exigir que o LinkedIn seja colado separadamente, é mudança de produto (não de bug) — me avisa que preparo a alteração no prompt + UI.

---

## 📦 Branding aplicado

**Cores oficiais Leone Berto extraídas do logo:**
- Navy primário:  `#0C2539`
- Dourado:        `#A08246`
- Bege:           `#F4EEE9`

**Fontes:** Playfair Display (serif, headings) + Inter (sans, body).

**Componente de header pronto:**
```tsx
import BrandHeader from "@/components/BrandHeader";
<BrandHeader variant="dark" />
```

**Cabeçalho do relatório PDF** — em `clientReportGenerator.ts` (arquivo do projeto), importe:
```ts
import { drawReportHeader, drawReportFooter, drawSectionTitle, drawScoreBadge } from "@/server/reportBrandHeader";
// use drawReportHeader(doc, 210, clientName, reportDate) no início de cada página
```
